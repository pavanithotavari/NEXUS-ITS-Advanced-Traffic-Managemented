# Edge AI-Based Adaptive Traffic Management for ITS

Ongoing work on a traffic management approach that runs AI models at the edge so decisions happen in real time.

- **Goal:** adjust traffic flow based on live road conditions and cut down congestion.
- **Approach:** machine learning and neural-network concepts applied to transportation problems
  (YOLO vehicle detection, neural-network + RandomForest demand forecasting, reinforcement-learning signal control).

Adaptive traffic-signal control that runs **on the edge** (Raspberry Pi / Jetson / industrial PC at the junction),
combining computer vision, ML demand forecasting and reinforcement learning.

```
Camera -> YOLO detector -> per-approach queue counts -> Controller (RL / actuated) -> Signal phase
                                   |                                  ^
                                   +--> ML forecaster (RandomForest) -+--> MQTT / dashboard / logs
```

## Components
| Module | Purpose |
|---|---|
| `simulator.py` | 4-way intersection simulator with rush-hour demand (no hardware needed) |
| `controller.py` | Fixed-time baseline, rule-based actuated, Q-learning controller |
| `predictor.py` | RandomForest / MLP neural-network next-minute traffic forecaster |
| `detector.py` | YOLOv8 vehicle detection + zone counting (video mode) |
| `edge_runtime.py` | Real-time loop: sense, decide, actuate, log, MQTT publish |
| `train_rl.py` / `evaluate.py` | Train and benchmark controllers |

## Quick start (VS Code)
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt && pip install -e .
python -m edge_traffic.train_rl                         # trains models/q_table.npy
python -m edge_traffic.evaluate                         # fixed vs actuated vs RL
python -m edge_traffic.train_forecaster --model mlp     # neural-net forecaster (or --model rf)
python -m edge_traffic.edge_runtime --source sim        # run the edge loop
pytest -q
```
Open the folder in VS Code and use **Run and Debug** (launch configs are included).

## Real camera / video mode
```bash
pip install opencv-python ultralytics
python -m edge_traffic.edge_runtime --source video --video traffic.mp4
```
Edit the `zones` in `config.yaml` to match your camera view. Hook your real signal controller
(GPIO relay / NTCIP) at the `TODO` in `edge_runtime.py`. **Always keep a hardware conflict monitor and
fail-safe fixed-time fallback in real deployments.**

## Push to your GitHub
```bash
# 1. Create an empty repo on github.com (e.g. edge-adaptive-traffic), then:
./scripts/push_to_github.sh https://github.com/<your-username>/edge-adaptive-traffic.git
```

## Roadmap ideas
- Swap simulator for SUMO / CityFlow; deep RL (DQN/PPO) with PyTorch
- Multi-intersection coordination (green wave)
- Emergency-vehicle preemption, pedestrian phases
- Quantised YOLO (ONNX/TensorRT/TFLite) for faster edge inference
