"""Compare fixed-time vs actuated vs Q-learning on identical demand seeds."""
import argparse
import numpy as np
from .config import load_config
from .simulator import Intersection
from .controller import FixedTimeController, ActuatedController, QLearningController


def run_episode(cfg, ctrl, seed, hour):
    env = Intersection(cfg, seed=seed, start_hour=hour)
    obs = env.reset()
    qsum, served = 0.0, 0
    for _ in range(cfg["sim"]["episode_steps"]):
        obs, _, _, info = env.step(ctrl.act(*obs))
        qsum += obs[0].sum()
        served += info["served"].sum()
    return qsum / cfg["sim"]["episode_steps"], served


def evaluate(cfg, q_path="models/q_table.npy", n=20):
    ctrls = [FixedTimeController(cfg), ActuatedController(cfg),
             QLearningController(cfg).load(q_path)]
    print(f"{'controller':<12}{'avg queue (veh)':>18}{'throughput (veh/h)':>22}")
    out = {}
    for c in ctrls:
        res = [run_episode(cfg, c, seed=1000 + i, hour=6 + (i * 14 / n)) for i in range(n)]
        aq, th = np.mean([r[0] for r in res]), np.mean([r[1] for r in res])
        out[c.name] = (aq, th)
        print(f"{c.name:<12}{aq:>18.2f}{th:>22.0f}")
    return out


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--config")
    p.add_argument("--q", default="models/q_table.npy")
    a = p.parse_args()
    evaluate(load_config(a.config), a.q)
